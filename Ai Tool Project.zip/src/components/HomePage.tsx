import { motion } from 'framer-motion';
import { BoltIcon, VideoCameraIcon, UserCircleIcon } from '@heroicons/react/24/outline';
import { Link } from 'react-router-dom';

export function HomePage() {
  return (
    <div className="min-h-screen bg-[#0a1628] text-white">
      {/* Navigation */}
      <nav className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <BoltIcon className="h-8 w-8 text-blue-500" />
              <span className="ml-2 text-xl font-bold">Shorts.lol</span>
            </div>
            <div className="flex space-x-8">
              <Link to="/dashboard" className="text-gray-300 hover:text-white">Dashboard</Link>
              <Link to="/explore" className="text-gray-300 hover:text-white">Explore</Link>
              <Link to="/pricing" className="text-gray-300 hover:text-white">Pricing</Link>
            </div>
            <UserCircleIcon className="h-8 w-8 text-gray-400 cursor-pointer" />
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              <h1 className="text-6xl font-bold tracking-tight">
                <span className="text-blue-500">Automate</span> Your Social<br />
                Media Virality with <span className="text-blue-500">AI</span>
              </h1>
              <p className="text-xl text-gray-400 max-w-2xl mx-auto">
                Use AI to easily create and share viral content across your platforms.
              </p>
              <div className="flex justify-center gap-4">
                <button className="bg-blue-600 text-white px-8 py-3 rounded-lg font-medium">
                  Turn Words into Videos
                </button>
                <button className="bg-blue-900/30 text-blue-400 px-8 py-3 rounded-lg font-medium border border-blue-800">
                  Join the Conversation on Discord
                </button>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Grid Background */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(to bottom right, rgba(10, 22, 40, 0.8), rgba(10, 22, 40, 0.95))`,
            backgroundSize: '20px 20px',
            backgroundPosition: 'center',
            backgroundRepeat: 'repeat',
            maskImage: 'radial-gradient(circle at center, transparent 0%, black 100%)'
          }}>
            <div className="absolute inset-0" style={{
              backgroundImage: `linear-gradient(rgba(0, 0, 255, 0.1) 1px, transparent 1px), 
                               linear-gradient(90deg, rgba(0, 0, 255, 0.1) 1px, transparent 1px)`,
              backgroundSize: '20px 20px'
            }}></div>
          </div>
        </div>
      </div>

      {/* Video Examples */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((item) => (
            <motion.div
              key={item}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: item * 0.1 }}
              className="aspect-video bg-gray-800 rounded-lg overflow-hidden"
            >
              <div className="w-full h-full bg-gradient-to-br from-blue-900/50 to-purple-900/50 flex items-center justify-center">
                <VideoCameraIcon className="h-12 w-12 text-blue-500" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}