import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronDownIcon, ChevronLeftIcon, ChevronRightIcon, ArrowLeftIcon, SpeakerWaveIcon, GlobeAltIcon, ClockIcon, VideoCameraIcon } from '@heroicons/react/24/outline';

const videoStyles = [
  { 
    id: 'realistic', 
    name: 'Realistic',
    background: 'bg-gradient-to-br from-orange-500/20 to-purple-500/20'
  },
  { 
    id: 'cartoon', 
    name: 'Cartoon',
    background: 'bg-gradient-to-br from-blue-500/20 to-pink-500/20'
  },
  { 
    id: 'comic', 
    name: 'Comic',
    background: 'bg-gradient-to-br from-green-500/20 to-yellow-500/20'
  },
];

const durations = ['15 seconds', '30 seconds', '60 seconds', 'Custom'];
const languages = ['English', 'Spanish', 'French', 'German', 'Italian'];
const voices = [
  { id: 'voice1', name: 'Emma (Female)', preview: 'Preview available' },
  { id: 'voice2', name: 'James (Male)', preview: 'Preview available' },
  { id: 'voice3', name: 'Sarah (Female)', preview: 'Preview available' },
];

export function VideoGenerator() {
  const [selectedStyle, setSelectedStyle] = useState('');
  const [isPublic, setIsPublic] = useState(false);

  return (
    <div className="min-h-screen bg-[#0a1628] text-white">
      <nav className="border-b border-gray-800 bg-[#0d1f36]">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center text-gray-300 hover:text-white">
            <ArrowLeftIcon className="h-5 w-5 mr-2" />
            Back to Home
          </Link>
          <div className="flex items-center space-x-4">
            <Link to="/dashboard/creations" className="text-gray-300 hover:text-white">
              My Creations
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto p-8">
        <div className="bg-[#0d1f36] rounded-lg p-8 space-y-8">
          {/* Content Type */}
          <div>
            <h2 className="text-2xl font-semibold mb-4">Content</h2>
            <textarea
              placeholder="Enter your video script or description here..."
              className="w-full h-32 bg-[#162942] border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* Style Selection */}
          <div>
            <h2 className="text-2xl font-semibold mb-4">Select a Style</h2>
            <div className="relative">
              <div className="flex space-x-4 overflow-hidden">
                {videoStyles.map((style) => (
                  <div
                    key={style.id}
                    className={`relative w-48 aspect-square rounded-lg overflow-hidden cursor-pointer ${style.background} ${
                      selectedStyle === style.id ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => setSelectedStyle(style.id)}
                  >
                    <div className="absolute bottom-4 left-4 text-white font-medium">
                      {style.name}
                    </div>
                  </div>
                ))}
              </div>
              <button className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-4 bg-gray-800/50 rounded-full p-1">
                <ChevronLeftIcon className="h-6 w-6" />
              </button>
              <button className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-4 bg-gray-800/50 rounded-full p-1">
                <ChevronRightIcon className="h-6 w-6" />
              </button>
            </div>
          </div>

          {/* Duration */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <ClockIcon className="h-6 w-6 text-blue-500" />
              <h2 className="text-2xl font-semibold">Duration</h2>
            </div>
            <div className="grid grid-cols-4 gap-4">
              {durations.map((duration) => (
                <button
                  key={duration}
                  className="bg-[#162942] hover:bg-[#1c3251] border border-gray-700 rounded-lg px-4 py-2 text-center"
                >
                  {duration}
                </button>
              ))}
            </div>
          </div>

          {/* Language */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <GlobeAltIcon className="h-6 w-6 text-blue-500" />
              <h2 className="text-2xl font-semibold">Video Language</h2>
            </div>
            <select className="w-full bg-[#162942] border border-gray-700 rounded-lg px-4 py-3 appearance-none">
              {languages.map((language) => (
                <option key={language} value={language}>{language}</option>
              ))}
            </select>
          </div>

          {/* Voice Over */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <SpeakerWaveIcon className="h-6 w-6 text-blue-500" />
              <h2 className="text-2xl font-semibold">Voice Over</h2>
            </div>
            <div className="space-y-4">
              {voices.map((voice) => (
                <div
                  key={voice.id}
                  className="flex items-center justify-between bg-[#162942] border border-gray-700 rounded-lg px-4 py-3"
                >
                  <div>
                    <div className="font-medium">{voice.name}</div>
                    <div className="text-sm text-gray-400">{voice.preview}</div>
                  </div>
                  <button className="text-blue-500 hover:text-blue-400">
                    Preview
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Video Status */}
          <div>
            <h2 className="text-2xl font-semibold mb-4">Video Status</h2>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={isPublic}
                onChange={(e) => setIsPublic(e.target.checked)}
                className="form-checkbox h-5 w-5 text-blue-500"
              />
              <span>Make this video public</span>
            </label>
          </div>

          {/* Generate Button */}
          <button className="w-full bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-medium flex items-center justify-center gap-2">
            <VideoCameraIcon className="h-5 w-5" />
            Generate Video
          </button>
        </div>

        {/* My Creations Preview */}
        <div className="mt-8 bg-[#0d1f36] rounded-lg p-8">
          <h2 className="text-2xl font-semibold mb-6">Recent Creations</h2>
          <div className="grid grid-cols-3 gap-4">
            {[1, 2, 3].map((item) => (
              <div key={item} className="aspect-video bg-[#162942] rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}