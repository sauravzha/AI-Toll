import { useState } from 'react';
import { motion } from 'framer-motion';
import { PlayIcon, PauseIcon } from '@heroicons/react/24/solid';
import clsx from 'clsx';

interface GeneratorState {
  isGenerating: boolean;
  progress: number;
}

export function MusicVideoGenerator() {
  const [text, setText] = useState('');
  const [generatorState, setGeneratorState] = useState<GeneratorState>({
    isGenerating: false,
    progress: 0,
  });

  const handleGenerate = async () => {
    if (!text.trim()) return;

    setGeneratorState({ isGenerating: true, progress: 0 });
    
    // Simulate generation progress
    for (let i = 0; i <= 100; i += 10) {
      await new Promise(resolve => setTimeout(resolve, 500));
      setGeneratorState(prev => ({ ...prev, progress: i }));
    }
    
    setGeneratorState(prev => ({ ...prev, isGenerating: false }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          <h1 className="text-4xl font-bold text-center mb-8">
            AI Music Video Generator
          </h1>

          <div className="bg-gray-800 rounded-lg p-6 shadow-xl">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter your lyrics or description here..."
              className="w-full h-40 bg-gray-700 text-white rounded-lg p-4 mb-4 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />

            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <button
                  onClick={handleGenerate}
                  disabled={generatorState.isGenerating || !text.trim()}
                  className={clsx(
                    "flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-colors",
                    generatorState.isGenerating || !text.trim()
                      ? "bg-gray-600 cursor-not-allowed"
                      : "bg-blue-600 hover:bg-blue-700"
                  )}
                >
                  {generatorState.isGenerating ? (
                    <PauseIcon className="w-5 h-5" />
                  ) : (
                    <PlayIcon className="w-5 h-5" />
                  )}
                  <span>
                    {generatorState.isGenerating ? 'Generating...' : 'Generate Video'}
                  </span>
                </button>
              </div>

              {generatorState.isGenerating && (
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${generatorState.progress}%` }}
                    className="bg-blue-500 h-2 rounded-full transition-all"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="bg-gray-800 rounded-lg p-6 shadow-xl">
            <h2 className="text-xl font-semibold mb-4">Preview</h2>
            <div className="aspect-video bg-gray-700 rounded-lg flex items-center justify-center">
              {generatorState.isGenerating ? (
                <div className="text-gray-400">Generating your video...</div>
              ) : (
                <div className="text-gray-400">Your video will appear here</div>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}