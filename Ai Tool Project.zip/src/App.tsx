import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { HomePage } from './components/HomePage';
import { VideoGenerator } from './components/VideoGenerator';
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/dashboard" element={<VideoGenerator />} />
        <Route path="/explore" element={<HomePage />} />
        <Route path="/pricing" element={<HomePage />} />
      </Routes>
    </Router>
  );
}

export default App;